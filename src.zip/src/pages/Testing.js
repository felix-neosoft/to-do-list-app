import React, { Component } from 'react'
import ls from 'localstorage-slim'


export class Testing extends Component {
    componentDidMount(){
        // let vinayal = JSON.parse(localStorage.getItem("vinayak"))
        // console.log(vinayal)
         let data = {"id":1,"task":"React 1","priority":"5"}
        // vinayal.push(data)
        // console.log(vinayal)
        //  localStorage.setItem("vinayak",JSON.stringify(vinayal ))

        // localStorage.setItem("vinayak",[])
        // if(localStorage.getItem("vinayak")){
        //     console.log("data exists")
        // }
        // else{
        //     console.log("data not exists")
        // }

        ls.config.encrypt = true;
        ls.set('vinayak',data)
        console.log(localStorage.getItem('vinayak'))
        let data1 = ls.get('vinayak')
        console.log(data1)




    }
    render() {

        return (
            <div>
                
            </div>
        )
    }
}

export default Testing
