import * as React from 'react';
import Box from '@mui/material/Box';
import Switch from '@mui/material/Switch';
import Paper from '@mui/material/Paper';
import Slide from '@mui/material/Slide';
import FormControlLabel from '@mui/material/FormControlLabel';
import { Button, TextField } from '@mui/material';
import { height } from '@mui/system';

const icon = (
  <Paper sx={{ m: 1 }} elevation={4}>
    <Box sx={{ width:1,height:300 }}>
      <TextField defaultValue="Hello" fullWidth/>
    </Box>
  </Paper>
);

const icon2 = (
  <Paper sx={{ m: 1 }} elevation={4}>
    <Box sx={{ width:1,height:300 }}>
      <TextField defaultValue="World" fullWidth/>
    </Box>
  </Paper>
);

export function SimpleSlide() {
  const [checked, setChecked] = React.useState(true);
  const [checked2, setChecked2] = React.useState(false);


  const handleChange = () => {
    setChecked((prev) => !prev);
    setChecked2((prev) => !prev);
  };

  return (
    <><Button onClick={() => handleChange()}>CLick Me</Button><Box sx={{ width: 1, height: 580 }}>
      <Box sx={{ my: 20, mx: "auto", width: `calc(500px + 16px)` }}>

        <Slide direction="down" in={checked} mountOnEnter unmountOnExit>
          {icon}
        </Slide>
        <Slide direction="top" in={checked2} mountOnEnter unmountOnExit>
          {icon2}
        </Slide>
      </Box>
    </Box></>
  );
}