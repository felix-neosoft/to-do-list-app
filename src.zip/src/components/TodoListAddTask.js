import React, {useRef, useState} from 'react'
import {Button, Paper, Box, TextField, FormControl, InputLabel, MenuItem, Select} from '@mui/material'
import ls from 'localstorage-slim'


function TodoListAddTask(props) {
    const taskinput = useRef(null)
    const [task,setTask] = useState("")
    const [errorTask, setErrorTask] = useState(null)
    const [errorText, setErrorText] = useState("")
    const [priority,setPriority] = useState('');

    const regForTask = RegExp('^[a-zA-z0-9 ]{6,100}$')

    const handler= () =>  {
       let taskvalue = taskinput.current.value
       let error = regForTask.test(taskvalue)?'':'Task entry must be alphanumeric and length is 6.'
       if(error !== ''){
           setErrorTask("error")
       }
       else{
           setErrorTask(null)
           setTask(taskinput.current.value)
       }
       setErrorText(error)
        
    }

    const handleChange = (event) => {
        setPriority(event.target.value)
    }
    
    const addEntry = () =>{
        if(errorTask === null && priority !== ''){
            let localData = ls.get(props.data) || []
            let data = {"task":task, "priority":priority}
            localData.push(data)
            ls.set(props.data,localData)
        }
        else{
            alert("Error!")
        }
    }
    return (
        <div>
            <Paper sx={{width:800, height:300, mx:"auto" ,mt:30}} elevation={5} variant="outlined" >
                <Box >
                    <TextField error={errorTask} sx={{width:600, mt:6, mx:12}} type="input" onChange={handler}  inputRef={taskinput} label="Task" variant="outlined" helperText= {errorText}/>
                    <Box sx={{ minWidth: 120 }}>
                        <FormControl sx={{width:600,mt:6,mx:12}}>
                            <InputLabel>Priority</InputLabel>
                            <Select value={priority} label="Priority" onChange={handleChange}>
                                <MenuItem value={1}>Priority: 1</MenuItem>
                                <MenuItem value={2}>Priority: 2</MenuItem>
                                <MenuItem value={3}>Priority: 3</MenuItem>
                                <MenuItem value={4}>Priority: 4</MenuItem>
                                <MenuItem value={5}>Priority: 5</MenuItem>
                            </Select>
                        </FormControl>
                    </Box>
                    <Button onClick={addEntry} sx={{mt:5, float:"right", mr:13}} variant="contained">Add Task</Button>
                </Box>
            </Paper>
        </div>
    )
}

export default TodoListAddTask
