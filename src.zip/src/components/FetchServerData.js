import axios from 'axios'
import {useState} from 'react'

export default function FetchServerData(url) {
    const [data,setdata] = useState([])
    axios.get(url).then(res=> setdata(res.data))
    return data
}